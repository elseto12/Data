//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.cpp
//
// Identification: src/buffer/lru_k_replacer.cpp
//
// Copyright (c) 2015-2022, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_k_replacer.h"
#include "common/exception.h"

namespace bustub {

LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k) : replacer_size_(num_frames), k_(k) {}

auto LRUKReplacer::Evict(frame_id_t *frame_id) -> bool {
  std::lock_guard<std::mutex> lock(latch_);
  
  if (curr_size_ == 0) {
    return false;
  }

  frame_id_t candidate = -1;
  size_t max_distance = 0;
  size_t candidate_earliest = std::numeric_limits<size_t>::max();

  for (const auto &[fid, frame_info] : frames_) {
    if (!frame_info.is_evictable) {
      continue;
    }

    size_t distance = ComputeBackwardKDistance(fid);
    size_t earliest_timestamp = frame_info.history.empty() ? current_timestamp_ : frame_info.history.front();

    bool update_candidate = false;
    if (candidate == -1) {
      update_candidate = true;
    } else if (distance > max_distance) {
      update_candidate = true;
    } else if (distance == max_distance && earliest_timestamp < candidate_earliest) {
      update_candidate = true;
    } else if (distance == max_distance && earliest_timestamp == candidate_earliest && fid < candidate) {
      update_candidate = true;
    }

    if (update_candidate) {
      candidate = fid;
      max_distance = distance;
      candidate_earliest = earliest_timestamp;
    }
  }

  if (candidate != -1) {
    *frame_id = candidate;
    frames_.erase(candidate);
    curr_size_--;
    return true;
  }

  return false;
}

void LRUKReplacer::RecordAccess(frame_id_t frame_id) {
  std::lock_guard<std::mutex> lock(latch_);

  if (static_cast<size_t>(frame_id) >= replacer_size_) {
    throw Exception("Frame id is larger than replacer size");
  }

  current_timestamp_++;

  if (frames_.find(frame_id) == frames_.end()) {
    frames_[frame_id] = FrameInfo{};
  }

  auto &frame_info = frames_[frame_id];
  
  frame_info.history.push_back(current_timestamp_);

  if (frame_info.history.size() > k_) {
    frame_info.history.pop_front();
  }
}

void LRUKReplacer::SetEvictable(frame_id_t frame_id, bool set_evictable) {
  std::lock_guard<std::mutex> lock(latch_);

  if (static_cast<size_t>(frame_id) >= replacer_size_) {
    throw Exception("Frame id is larger than replacer size");
  }

  auto it = frames_.find(frame_id);
  if (it == frames_.end()) {
    return;
  }

  auto &frame_info = it->second;
  
  if (frame_info.is_evictable && !set_evictable) {
    frame_info.is_evictable = false;
    curr_size_--;
  } else if (!frame_info.is_evictable && set_evictable) {
    frame_info.is_evictable = true;
    curr_size_++;
  }
}

void LRUKReplacer::Remove(frame_id_t frame_id) {
  std::lock_guard<std::mutex> lock(latch_);

  if (static_cast<size_t>(frame_id) >= replacer_size_) {
    throw Exception("Frame id is larger than replacer size");
  }

  auto it = frames_.find(frame_id);
  if (it == frames_.end()) {
    return;
  }

  if (!it->second.is_evictable) {
    throw Exception("Cannot remove non-evictable frame");
  }

  frames_.erase(it);
  curr_size_--;
}

auto LRUKReplacer::Size() -> size_t {
  std::lock_guard<std::mutex> lock(latch_);
  return curr_size_;
}

auto LRUKReplacer::ComputeBackwardKDistance(frame_id_t frame_id) -> size_t {
  const auto &frame_info = frames_[frame_id];
  
  if (frame_info.history.size() < k_) {
    return std::numeric_limits<size_t>::max();
  }
  
  return current_timestamp_ - frame_info.history.front();
}

}  // namespace bustub
